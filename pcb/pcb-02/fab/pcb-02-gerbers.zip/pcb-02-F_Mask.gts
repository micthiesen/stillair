G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-07-30T17:12:16-07:00*
G04 #@! TF.ProjectId,pcb-02,7063622d-3032-42e6-9b69-6361645f7063,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-07-30 17:12:16*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.200000X-0.587500X-0.150000X0.587500X-0.150000X0.587500X0.150000X-0.587500X0.150000X0*%
%ADD11C,2.300000*%
%ADD12RoundRect,0.275000X-0.225000X-0.250000X0.225000X-0.250000X0.225000X0.250000X-0.225000X0.250000X0*%
%ADD13RoundRect,0.300000X0.625000X-0.350000X0.625000X0.350000X-0.625000X0.350000X-0.625000X-0.350000X0*%
%ADD14O,1.850000X1.300000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,U1*
X51562500Y-53050000D03*
X51562500Y-54950000D03*
X53437500Y-54000000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,H2*
X63000000Y-54000000D03*
G04 #@! TD*
G04 #@! TO.C,H1*
X57000000Y-54000000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,C1*
X51725000Y-51300000D03*
X53275000Y-51300000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,J1*
X67700000Y-56000000D03*
D14*
X67700000Y-54000000D03*
X67700000Y-52000000D03*
G04 #@! TD*
M02*
